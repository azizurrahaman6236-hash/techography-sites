techography-magnet - source code
Live: https://techography-magnet.sites.tab.bot/
Made for @_techography

Kaise chalayein: is folder ki index.html browser mein kholo, ya kisi bhi static hosting pe upload karo
(GitHub Pages, Netlify, Vercel - poora folder as-is).
