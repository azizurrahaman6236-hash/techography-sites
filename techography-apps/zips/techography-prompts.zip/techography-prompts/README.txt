techography-prompts - source code
Live: https://techography-prompts.sites.tab.bot/
Made for @_techography

Kaise chalayein: is folder ki index.html browser mein kholo, ya kisi bhi static hosting pe upload karo
(GitHub Pages, Netlify, Vercel - poora folder as-is).
