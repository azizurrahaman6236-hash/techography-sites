const N=43, SIZE=33751060, PS=800000;
async function part(env, origin, i) {
  const r = await env.ASSETS.fetch(new URL("/parts/p" + String(i).padStart(3,"0") + ".bin", origin));
  return new Uint8Array(await r.arrayBuffer());
}
export default {
  async fetch(req, env) {
    const url = new URL(req.url);
    if (url.pathname === "/reel.mp4") {
      let start = 0, end = SIZE - 1, status = 200;
      const rg = req.headers.get("range");
      const m = rg && /^bytes=(\d*)-(\d*)$/.exec(rg.trim());
      if (m) {
        if (m[1] === "" && m[2] !== "") { start = Math.max(0, SIZE - parseInt(m[2])); }
        else { start = parseInt(m[1] || "0"); if (m[2] !== "") end = Math.min(SIZE - 1, parseInt(m[2])); }
        if (start >= SIZE || start > end) return new Response(null, {status: 416, headers: {"content-range": `bytes */${SIZE}`}});
        status = 206;
      }
      const len = end - start + 1;
      const headers = {"content-type":"video/mp4","content-length":String(len),"accept-ranges":"bytes","cache-control":"public, max-age=86400"};
      if (status === 206) headers["content-range"] = `bytes ${start}-${end}/${SIZE}`;
      if (req.method === "HEAD") return new Response(null, {status, headers});
      const {readable, writable} = new FixedLengthStream(len);
      (async () => {
        const w = writable.getWriter();
        for (let i = Math.floor(start / PS); i <= Math.floor(end / PS); i++) {
          const b = await part(env, url.origin, i);
          const s = Math.max(start - i * PS, 0), e = Math.min(end - i * PS + 1, b.length);
          await w.write(b.subarray(s, e));
        }
        await w.close();
      })().catch(e => writable.abort(e));
      return new Response(readable, {status, headers});
    }
    return env.ASSETS.fetch(req);
  }
};
