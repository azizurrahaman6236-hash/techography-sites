techography-hidden-cam - source code
Live: https://techography-hidden-cam.sites.tab.bot/
Made for @_techography

Kaise chalayein: is folder ki index.html browser mein kholo, ya kisi bhi static hosting pe upload karo
(GitHub Pages, Netlify, Vercel - poora folder as-is).
hidden_cam_scanner.py PC pe Python se chalao; phone-app/ phone browser mein khulta hai.