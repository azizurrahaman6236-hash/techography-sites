techography-cyclone-arnab - source code
Live: https://techography-cyclone-arnab.sites.tab.bot/
Made for @_techography

Kaise chalayein: is folder ki index.html browser mein kholo, ya kisi bhi static hosting pe upload karo
(GitHub Pages, Netlify, Vercel - poora folder as-is).
_worker.js ek Cloudflare Worker hai jo reel video stream karta hai. Page ke liye index.html kaafi hai.
Zip chhota rakhne ke liye 43 badi media files (video parts etc.) shamil nahi hain; woh live site pe hi hain.
